# PBula 1.0

Aplicação Flutter do PBula, com identidade visual baseada no logo fornecido.

## Incluído
- Login/cadastro de demonstração
- Chat
- Histórico
- Perfil
- Definições
- Português (Angola), Português (Brasil), Português (Portugal), Inglês, Francês e Espanhol
- Tema claro/escuro
- Logo PBula em `assets/pbula_logo.jpg`

## Importante
A tela de chat nesta versão é uma implementação local de demonstração. Para respostas reais de IA é necessário ligar um backend seguro a um provedor de IA. A chave da API não deve ser colocada diretamente no aplicativo.

## Compilar
Com Flutter instalado:

```bash
flutter pub get
flutter run
flutter build apk --release
```

O APK de release normalmente será criado em:

`build/app/outputs/flutter-apk/app-release.apk`
